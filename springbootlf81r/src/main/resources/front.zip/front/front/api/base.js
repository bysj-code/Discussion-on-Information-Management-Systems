﻿const base = {
    url : "http://localhost:8080/springbootlf81r/"
}
export default base
